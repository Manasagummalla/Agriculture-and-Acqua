from django.shortcuts import render,redirect
from shopapp.models import *
from django.contrib import messages
from django.db.models import Max,Sum
from matplotlib import pyplot as plt

# Create your views here.
def dashboard(req):
    totalusers=Users.objects.filter(role='Customer').count()
    totalproducts=Product.objects.count()
    totalcategories=Category.objects.count()
    totalorders=Order.objects.count()
    prods=[]
    sales=[]
    for item in Product.objects.all():        
        prods.append(item.pname)
        sale=OrderDetails.objects.filter(product=item).aggregate(total=Sum('qty'))['total']
        print(sale)
        sales.append(0 if sale==None else sale)
    plt.bar(prods,sales)
    plt.savefig('shopapp/static/data.png')
    plt.close()
    return render(req,"dashboard.html",locals())

def userslist(req):
    users=Users.objects.filter(role='Customer')
    return render(req,"users.html",locals())

def changepwd(req):
    if(req.method=="POST"):
        userid=req.session["userid"]
        user=Users.objects.get(pk=userid)
        if(user.pwd==req.POST.get("opwd")):
            user.pwd=req.POST.get("pwd")
            user.save()
            messages.success(req,"Password updated successfully")
        else:
            messages.error(req,"Incorrect current password")    
    return render(req,"changepwd.html")

def orderslist(req):
    orders=Order.objects.all().order_by("-id")
    return render(req,"orders.html",locals())

def orderdetails(req,oid):
    o=Order.objects.get(pk=oid)
    details=OrderDetails.objects.filter(order=o)
    return render(req,"orderdetails.html",locals())

def confirmorder(req,oid):
    o=Order.objects.get(pk=oid)
    o.status="Confirmed"
    o.save()
    messages.success(req,"Order confirmed")
    return redirect("/orders")

def categories(req,catid=None):
    if(req.method=="POST"):
        catname=req.POST.get("catname")        
        cat=Category(catname=catname)
        if(catid is not None):
            cat.catid=catid
        cat.save()
        messages.success(req,"Category saved successfully")
        return redirect("/categories")
    cats=Category.objects.all()
    if(catid is not None):
        c=Category.objects.get(pk=catid)                
    return render(req,"categories.html",locals())

def products(req,prodid=None):
    if(req.method=="POST"):
        prodid=req.POST.get("pid")
        pname=req.POST.get("pname") 
        price=req.POST.get("price")
        photo=req.FILES.get("photo")                    
        category=Category.objects.get(pk=req.POST.get("catid"))       
        product=Product(pname=pname,pid=prodid,category=category,price=price,photo=photo) 
        product.save()
        messages.success(req,"Product saved successfully")
        return redirect("/products")
    cats=Category.objects.all()
    if(prodid is not None):
        c=Product.objects.get(pk=prodid)
        proid=c.pid
        edit=True
    else:
        proid=101 if Product.objects.count()==0 else Product.objects.aggregate(max=Max('pid'))["max"]+1
    prods=Product.objects.all()
    return render(req,"products.html",locals())

def updateproduct(req):
    prodid=req.POST.get("pid")
    product=Product.objects.get(pk=prodid)
    product.pname=req.POST.get("pname") 
    product.price=req.POST.get("price")                  
    product.category=Category.objects.get(pk=req.POST.get("catid"))        
    print(product)
    product.save()
    messages.success(req,"Product saved successfully")
    return redirect("/products")