"""AgriculureShop URL Configuration

Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static,settings
from shopapp import views as cviews
from adminapp import views as aviews


urlpatterns = [
    path('', cviews.homepage),
    path('login/', cviews.loginpage),
    path('logout/', cviews.logout),
    path('dashboard/', aviews.dashboard),
    path('categories/', aviews.categories),
    path('products/', aviews.products),
    path('users/', aviews.userslist),
    path('register/',cviews.registeruser),
    path('changepwd/',aviews.changepwd),
    path('cchangepwd/',cviews.changepwd),
    path('products/<int:prodid>', aviews.products),
    path('categories/<int:catid>', aviews.categories),
    path('addtocart/<int:pid>', cviews.addtocart),
    path('cart/', cviews.viewcart),
    path('cats/<int:catid>', cviews.categoryview),
    path('delivery/', cviews.orderplace),
    path('history/', cviews.orderhistory),
    path('orderdetails/<int:oid>', cviews.orderdetails),
    path('orders/', aviews.orderslist),
    path('update/', aviews.updateproduct),
    path('details/<int:oid>', aviews.orderdetails),
    path('confirm/<int:oid>', aviews.confirmorder),
    path('cancel/<int:oid>', cviews.cancelorder),
    path('admin/', admin.site.urls),
]

urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)