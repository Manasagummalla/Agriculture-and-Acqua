from django.db import models

# Create your models here.
class Users(models.Model):
    userid=models.CharField(max_length=30,primary_key=True)
    uname=models.CharField(max_length=30)
    pwd=models.CharField(max_length=20)
    role=models.CharField(max_length=20)

    class Meta:
        db_table="users"


class Category(models.Model):
    catid=models.AutoField(primary_key=True)
    catname=models.CharField(max_length=30)
    
    class Meta:
        db_table="categories"

class Product(models.Model):
    pid=models.IntegerField(primary_key=True)
    pname=models.CharField(max_length=30)
    category=models.ForeignKey(to=Category,on_delete=models.CASCADE)
    price=models.DecimalField(max_digits=14,decimal_places=2)
    photo=models.ImageField(upload_to='pics',null=True)

    class Meta:
        db_table="products"
    

class Cart(models.Model):
    product=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    user=models.ForeignKey(to=Users,on_delete=models.CASCADE)
    qty=models.IntegerField()

    def get_amount(self):
        return self.product.price*self.qty

    class Meta:
        unique_together=(('product','user'))
        db_table="cart"

class Order(models.Model):
    id=models.AutoField(primary_key=True)
    orderdate=models.DateField(auto_now=True)
    user=models.ForeignKey(to=Users,on_delete=models.CASCADE)
    status=models.CharField(max_length=15,default='Pending')

    class Meta:
        db_table="orders"

class OrderDetails(models.Model):
    id=models.AutoField(primary_key=True)
    order=models.ForeignKey(to=Order,on_delete=models.CASCADE)
    product=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    qty=models.IntegerField()

    def get_amount(self):
        return self.product.price*self.qty

    class Meta:
        db_table="order_details"
