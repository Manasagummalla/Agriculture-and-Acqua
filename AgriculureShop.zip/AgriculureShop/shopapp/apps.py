from django.apps import AppConfig


class ShopappConfig(AppConfig):
    name = 'shopapp'
