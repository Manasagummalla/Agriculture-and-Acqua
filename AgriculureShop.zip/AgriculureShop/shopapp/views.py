from django.shortcuts import render,redirect
from shopapp.models import *
from django.contrib import messages
from django.db.models import Max,Sum
from django.db import connection

# Create your views here.
def homepage(req):
    products=Product.objects.all()
    cats=Category.objects.all()
    if('userid' in req.session):
        user=Users.objects.get(pk=req.session["userid"])
        cqty=Cart.objects.filter(user=user).count()
    return render(req,"home.html",locals())

def changepwd(req):
    if(req.method=="POST"):
        userid=req.session["userid"]
        user=Users.objects.get(pk=userid)
        if(user.pwd==req.POST.get("opwd")):
            user.pwd=req.POST.get("pwd")
            user.save()
            messages.success(req,"Password updated successfully")
        else:
            messages.error(req,"Incorrect current password")    
    return render(req,"achangepwd.html")

def categoryview(req,catid):
    category=Category.objects.get(pk=catid)
    products=Product.objects.filter(category=category)
    cats=Category.objects.all()
    if('userid' in req.session):
        user=Users.objects.get(pk=req.session["userid"])
        cqty=Cart.objects.filter(user=user).count()
    return render(req,"category.html",locals())

def loginpage(req):
    if(req.method=="POST"):
        userid=req.POST.get("userid")
        pwd=req.POST.get("pwd")
        user=Users.objects.filter(userid=userid,pwd=pwd)
        if(len(user)==0):
            messages.error(req,"Invalid username or password")
        else:
            req.session["userid"]=userid
            req.session["role"]=user[0].role
            req.session["uname"]=user[0].uname
            if(user[0].role=='admin'):
                return redirect('/dashboard')
            else:
                return redirect('/')
    cats=Category.objects.all()
    return render(req,"login.html",locals())

def registeruser(req):
    userid=req.POST.get("userid")
    uname=req.POST.get("uname")
    pwd=req.POST.get("pwd")
    user=Users(userid=userid,uname=uname,pwd=pwd,role='Customer')
    user.save()
    req.session["userid"]=userid
    req.session["uname"]=uname
    req.session["role"]='Customer'
    messages.success(req,"User registered successfully")
    return redirect("/")

def addtocart(req,pid):
    if(req.method=="POST"):
        print(req.session)
        product=Product.objects.get(pk=pid)
        qty=req.POST.get("qty")
        cart=Cart(user=Users.objects.get(pk=req.session["userid"]),product=product,qty=qty)
        cart.save()
        messages.success(req,"Item added to cart successfully")
        return redirect("/")
    p=Product.objects.get(pk=pid)
    cats=Category.objects.all()
    if('userid' in req.session):
        user=Users.objects.get(pk=req.session["userid"])
        cqty=Cart.objects.filter(user=user).count()
    return render(req,"addtocart.html",locals())

def viewcart(req):
    userid=req.session["userid"]
    user=Users.objects.get(pk=req.session["userid"])
    citems=Cart.objects.filter(user=user)
    cqty=citems.count()
    ctotal=0
    for citem in citems :
        ctotal+=citem.get_amount()    
    print(ctotal)
    ctax=ctotal * 10/100
    netamount=ctotal+ctax
    cats=Category.objects.all()
    return render(req,"cart.html",locals())

def orderplace(req):
    user=Users.objects.get(pk=req.session["userid"])
    order=Order(user=user)
    order.save()

    for item in Cart.objects.filter(user=user):
        order_details=OrderDetails(order=order,product=item.product,qty=item.qty)
        order_details.save()
    cart=Cart.objects.filter(user=user)
    cart.delete()
    messages.success(req,"Order Placed successfully")
    return redirect("/history")

def orderhistory(req):
    user=Users.objects.get(pk=req.session["userid"])
    orders=Order.objects.filter(user=user)
    cats=Category.objects.all()
    return render(req,"orderhistory.html",locals())

def orderdetails(req,oid):
    o=Order.objects.get(pk=oid)
    odetails=OrderDetails.objects.filter(order=o)
    cqty=odetails.count()
    ctotal=0
    for citem in odetails :
        ctotal+=citem.get_amount()    
    print(ctotal)
    ctax=ctotal * 10/100
    netamount=ctotal+ctax
    cats=Category.objects.all()
    return render(req,"order_details.html",locals())

def cancelorder(req,oid):
    o=Order.objects.get(pk=oid)
    o.delete()
    messages.success(req,"Order cancelled successfully")
    return redirect("/history")

def logout(req):
    req.session.clear()
    return redirect('/')
